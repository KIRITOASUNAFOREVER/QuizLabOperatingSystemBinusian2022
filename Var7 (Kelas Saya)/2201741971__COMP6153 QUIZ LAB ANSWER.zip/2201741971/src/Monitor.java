
public class Monitor extends ProductType{

	public Monitor() {
		super();
	}
}
